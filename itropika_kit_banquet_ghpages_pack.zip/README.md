# Itropika – Kit Banquets (GitHub Pages Pack)

Ce dépôt contient une page HTML responsive (assets intégrés en base64) et un PDF téléchargeable, prêts à être publiés via **GitHub Pages**.

## 📦 Contenu
- `index.html` — la page principale (logo, bannière, CTA e-mail/WhatsApp, sections, atouts, etc.).
- `docs/itropika_kit_banquet.pdf` — version PDF à partager/télécharger.
- `404.html` — page d’erreur.
- `.nojekyll` — empêche le traitement Jekyll (recommandé).

## 🚀 Mise en ligne (GitHub Pages)
1. Créez un compte sur https://github.com (si besoin).
2. Créez un nouveau dépôt public, par ex. **itropika-banquet**.
3. Uploadez tous les fichiers de ce dossier (ou poussez en `git`).
4. Dans le dépôt, allez à **Settings → Pages** :
   - **Build and deployment**: *Deploy from a branch*
   - **Branch**: *main* (ou *master*) — **/ (root)**
   - Cliquez **Save**
5. Votre site sera disponible sous :  
   `https://<votre-utilisateur>.github.io/itropika-banquet/`
   - La page d’accueil : `https://<votre-utilisateur>.github.io/itropika-banquet/`
   - Le PDF : `https://<votre-utilisateur>.github.io/itropika-banquet/docs/itropika_kit_banquet.pdf`

## 🏷️ URL personnalisée (optionnel)
Vous pouvez connecter un domaine comme `banquets.itropika.com` :
- **Settings → Pages → Custom domain**
- Ajoutez votre domaine et suivez les instructions DNS (CNAME).

## 🛠️ Conseils
- Pour renommer le PDF, modifiez le nom de fichier dans `docs/` et mettez à jour les liens si vous en ajoutez dans `index.html`.
- Les images/icônes sont intégrées en base64 — aucune ressource externe n’est nécessaire.

— Itropika Beach Tabarka